<div class="container">
    <h2 class="text-uppercase fw-bold text-center mb-3" data-aos="fade-up">
        GUIDELINES FOR
        <span class="secondary_color">SUBMISSION</span>
    </h2>


    <section>
        <?php include_once('abstract.php') ?>
    </section>

    <section>
        <?php include_once('extended_abstract.php') ?>
    </section>
</div>