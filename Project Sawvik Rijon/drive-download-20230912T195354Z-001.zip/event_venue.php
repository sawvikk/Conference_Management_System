<div class="container" style="width: 90vw">
    <h2 class="text-uppercase fw-bold text-center mb-3" data-aos="fade-up">Event <span class="secondary_color">Venue</span> </h2>
    <div>
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3628.2084231573626!2d90.37299865031345!3d24.582002262338282!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3756417d5fe9a2a3%3A0xc4807b9570837651!2sJatiya%20Kabi%20Kazi%20Nazrul%20Islam%20University%20(JKKNIU)!5e0!3m2!1sen!2sbd!4v1677002280216!5m2!1sen!2sbd" style="border: 0; width: 100%; height: 50vh" allowFullScreen="allowFullScreen" loading="lazy" data-aos="fade-up"></iframe>
    </div>
</div>