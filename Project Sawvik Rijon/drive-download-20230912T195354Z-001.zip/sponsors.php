<div class="container">
    <h2 class="text-uppercase fw-bold text-center mb-3" data-aos="fade-up"><span class="secondary_color">Our Sponsors</span></h2>
    <div class="row">
    <h4 class="col text-uppercase fw-bold text-center mb-3 text-decoration-underline" data-aos="fade-up">Platinum sponsor</h4>
    <h4 class="col text-uppercase fw-bold text-center mb-3 text-decoration-underline" data-aos="fade-up">Gold sponsor</h4>
    <h4 class="col text-uppercase fw-bold text-center mb-3 text-decoration-underline" data-aos="fade-up">silver sponsor</h4>
    </div>
    <div class="row" style="margin:20px">
        <h6 class="col text-uppercase fw-bold text-center mb-3 text-decoration-underline" data-aos="fade-up">Other sponsors</h6>
    </div>
</div>